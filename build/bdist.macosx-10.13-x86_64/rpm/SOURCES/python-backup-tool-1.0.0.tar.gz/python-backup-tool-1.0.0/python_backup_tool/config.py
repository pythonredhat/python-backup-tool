source_dir =  "/opt/django-developer-portfolio"
destination_dir = "/tmp/backup/"
destination_ip = "192.168.56.102"
rsync_user = "root"
