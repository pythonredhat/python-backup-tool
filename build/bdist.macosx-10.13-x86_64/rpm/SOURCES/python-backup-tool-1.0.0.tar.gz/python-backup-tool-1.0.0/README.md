### resource for ssh and progress bar
```bash
https://www.digitalocean.com/community/tutorials/how-to-copy-files-with-rsync-over-ssh
```
```bash
need to add to rpm:
    -install python 3:
    sudo yum install rh-python36
    scl enable rh-python36 bash
```
